
export default function Home() {
  return (
    <div style={{textAlign:'center', marginTop:'50px'}}>
      <h1>Welcome to Dock of the Bay</h1>
      <p>Interactive site is working!</p>
    </div>
  )
}
